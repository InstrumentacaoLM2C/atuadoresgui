﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Parâmetros_Motor = new System.Windows.Forms.GroupBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.Enviar = new System.Windows.Forms.Button();
            this.Velocity = new System.Windows.Forms.Button();
            this.Direction2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.PulseQntd = new System.Windows.Forms.Button();
            this.Direction = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.SemAcelerar = new System.Windows.Forms.Button();
            this.En_Button = new System.Windows.Forms.Button();
            this.onButton = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.StopButton = new System.Windows.Forms.Button();
            this.serialPort2 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button23 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.ModoCalibracao = new System.Windows.Forms.Button();
            this.ModoMovimentacao = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.portComboBox = new System.Windows.Forms.ComboBox();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.Aceleracao_calibracao = new System.Windows.Forms.Button();
            this.Sem_Aceleracao_calibracao = new System.Windows.Forms.Button();
            this.calibrar = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.A_laser = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button20 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.button48 = new System.Windows.Forms.Button();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button51 = new System.Windows.Forms.Button();
            this.ET12C = new System.Windows.Forms.GroupBox();
            this.button52 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.button56 = new System.Windows.Forms.Button();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.button57 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.button60 = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.button41 = new System.Windows.Forms.Button();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button44 = new System.Windows.Forms.Button();
            this.ETExtracao = new System.Windows.Forms.GroupBox();
            this.button25 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button34 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button37 = new System.Windows.Forms.Button();
            this.ET12 = new System.Windows.Forms.GroupBox();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button53 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button58 = new System.Windows.Forms.Button();
            this.Parâmetros_Motor.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.ET12C.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.ETExtracao.SuspendLayout();
            this.ET12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.SuspendLayout();
            // 
            // Parâmetros_Motor
            // 
            resources.ApplyResources(this.Parâmetros_Motor, "Parâmetros_Motor");
            this.Parâmetros_Motor.Controls.Add(this.textBox15);
            this.Parâmetros_Motor.Controls.Add(this.textBox8);
            this.Parâmetros_Motor.Controls.Add(this.textBox10);
            this.Parâmetros_Motor.Controls.Add(this.textBox9);
            this.Parâmetros_Motor.Controls.Add(this.Enviar);
            this.Parâmetros_Motor.Controls.Add(this.Velocity);
            this.Parâmetros_Motor.Controls.Add(this.Direction2);
            this.Parâmetros_Motor.Controls.Add(this.textBox1);
            this.Parâmetros_Motor.Controls.Add(this.PulseQntd);
            this.Parâmetros_Motor.Controls.Add(this.Direction);
            this.Parâmetros_Motor.Controls.Add(this.textBox2);
            this.Parâmetros_Motor.Controls.Add(this.button13);
            this.Parâmetros_Motor.Controls.Add(this.button14);
            this.Parâmetros_Motor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Parâmetros_Motor.Name = "Parâmetros_Motor";
            this.Parâmetros_Motor.TabStop = false;
            // 
            // textBox15
            // 
            resources.ApplyResources(this.textBox15, "textBox15");
            this.textBox15.Name = "textBox15";
            // 
            // textBox8
            // 
            resources.ApplyResources(this.textBox8, "textBox8");
            this.textBox8.Name = "textBox8";
            // 
            // textBox10
            // 
            this.textBox10.AcceptsReturn = true;
            resources.ApplyResources(this.textBox10, "textBox10");
            this.textBox10.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBox10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            // 
            // textBox9
            // 
            this.textBox9.AcceptsReturn = true;
            resources.ApplyResources(this.textBox9, "textBox9");
            this.textBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBox9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            // 
            // Enviar
            // 
            resources.ApplyResources(this.Enviar, "Enviar");
            this.Enviar.Name = "Enviar";
            this.Enviar.UseVisualStyleBackColor = true;
            this.Enviar.Click += new System.EventHandler(this.Enviar_Click_1);
            // 
            // Velocity
            // 
            resources.ApplyResources(this.Velocity, "Velocity");
            this.Velocity.Name = "Velocity";
            this.Velocity.UseVisualStyleBackColor = true;
            this.Velocity.Click += new System.EventHandler(this.Velocity_Click_1);
            // 
            // Direction2
            // 
            resources.ApplyResources(this.Direction2, "Direction2");
            this.Direction2.Name = "Direction2";
            this.Direction2.UseVisualStyleBackColor = true;
            this.Direction2.Click += new System.EventHandler(this.Direction2_Click_1);
            // 
            // textBox1
            // 
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            // 
            // PulseQntd
            // 
            resources.ApplyResources(this.PulseQntd, "PulseQntd");
            this.PulseQntd.Name = "PulseQntd";
            this.PulseQntd.UseVisualStyleBackColor = true;
            this.PulseQntd.Click += new System.EventHandler(this.PulseQntd_Click_1);
            // 
            // Direction
            // 
            resources.ApplyResources(this.Direction, "Direction");
            this.Direction.Name = "Direction";
            this.Direction.UseVisualStyleBackColor = true;
            this.Direction.Click += new System.EventHandler(this.Direction_Click_1);
            // 
            // textBox2
            // 
            resources.ApplyResources(this.textBox2, "textBox2");
            this.textBox2.Name = "textBox2";
            // 
            // button13
            // 
            resources.ApplyResources(this.button13, "button13");
            this.button13.Name = "button13";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click_1);
            // 
            // button14
            // 
            resources.ApplyResources(this.button14, "button14");
            this.button14.Name = "button14";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // groupBox1
            // 
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Controls.Add(this.button6);
            this.groupBox1.Controls.Add(this.SemAcelerar);
            this.groupBox1.Controls.Add(this.En_Button);
            this.groupBox1.Controls.Add(this.onButton);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.StopButton);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // button6
            // 
            resources.ApplyResources(this.button6, "button6");
            this.button6.Name = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // SemAcelerar
            // 
            resources.ApplyResources(this.SemAcelerar, "SemAcelerar");
            this.SemAcelerar.Name = "SemAcelerar";
            this.SemAcelerar.UseVisualStyleBackColor = true;
            this.SemAcelerar.Click += new System.EventHandler(this.SemAcelerar_Click_1);
            // 
            // En_Button
            // 
            resources.ApplyResources(this.En_Button, "En_Button");
            this.En_Button.Name = "En_Button";
            this.En_Button.UseVisualStyleBackColor = true;
            this.En_Button.Click += new System.EventHandler(this.En_Button_Click);
            // 
            // onButton
            // 
            resources.ApplyResources(this.onButton, "onButton");
            this.onButton.Name = "onButton";
            this.onButton.UseVisualStyleBackColor = true;
            this.onButton.Click += new System.EventHandler(this.onButton_Click_1);
            // 
            // textBox4
            // 
            this.textBox4.AcceptsReturn = true;
            resources.ApplyResources(this.textBox4, "textBox4");
            this.textBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBox4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged_1);
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // StopButton
            // 
            resources.ApplyResources(this.StopButton, "StopButton");
            this.StopButton.Name = "StopButton";
            this.StopButton.UseVisualStyleBackColor = true;
            this.StopButton.Click += new System.EventHandler(this.StopButton_Click_1);
            // 
            // serialPort2
            // 
            this.serialPort2.PortName = "COM9";
            this.serialPort2.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort2_DataReceived);
            // 
            // groupBox2
            // 
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Controls.Add(this.groupBox1);
            this.groupBox2.Controls.Add(this.Parâmetros_Motor);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Controls.Add(this.button23);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.ModoCalibracao);
            this.groupBox3.Controls.Add(this.ModoMovimentacao);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // button23
            // 
            resources.ApplyResources(this.button23, "button23");
            this.button23.Name = "button23";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button7
            // 
            resources.ApplyResources(this.button7, "button7");
            this.button7.Name = "button7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // ModoCalibracao
            // 
            resources.ApplyResources(this.ModoCalibracao, "ModoCalibracao");
            this.ModoCalibracao.Name = "ModoCalibracao";
            this.ModoCalibracao.UseVisualStyleBackColor = true;
            this.ModoCalibracao.Click += new System.EventHandler(this.ModoCalibracao_Click);
            // 
            // ModoMovimentacao
            // 
            resources.ApplyResources(this.ModoMovimentacao, "ModoMovimentacao");
            this.ModoMovimentacao.Name = "ModoMovimentacao";
            this.ModoMovimentacao.UseVisualStyleBackColor = true;
            this.ModoMovimentacao.Click += new System.EventHandler(this.ModoMovimentacao_Click);
            // 
            // button12
            // 
            resources.ApplyResources(this.button12, "button12");
            this.button12.Name = "button12";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click_1);
            // 
            // portComboBox
            // 
            resources.ApplyResources(this.portComboBox, "portComboBox");
            this.portComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.portComboBox.FormattingEnabled = true;
            this.portComboBox.Name = "portComboBox";
            this.portComboBox.Sorted = true;
            this.portComboBox.SelectedIndexChanged += new System.EventHandler(this.portComboBox_SelectedIndexChanged);
            // 
            // button11
            // 
            resources.ApplyResources(this.button11, "button11");
            this.button11.Name = "button11";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox4
            // 
            resources.ApplyResources(this.groupBox4, "groupBox4");
            this.groupBox4.Controls.Add(this.textBox16);
            this.groupBox4.Controls.Add(this.button10);
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button8);
            this.groupBox4.Controls.Add(this.textBox12);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.Aceleracao_calibracao);
            this.groupBox4.Controls.Add(this.Sem_Aceleracao_calibracao);
            this.groupBox4.Controls.Add(this.calibrar);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.textBox6);
            this.groupBox4.Controls.Add(this.A_laser);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.TabStop = false;
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // textBox16
            // 
            this.textBox16.AcceptsReturn = true;
            resources.ApplyResources(this.textBox16, "textBox16");
            this.textBox16.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBox16.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.TextChanged += new System.EventHandler(this.textBox16_TextChanged);
            // 
            // button10
            // 
            resources.ApplyResources(this.button10, "button10");
            this.button10.Name = "button10";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            resources.ApplyResources(this.button9, "button9");
            this.button9.Name = "button9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            resources.ApplyResources(this.button8, "button8");
            this.button8.Name = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox12
            // 
            resources.ApplyResources(this.textBox12, "textBox12");
            this.textBox12.Name = "textBox12";
            // 
            // button5
            // 
            resources.ApplyResources(this.button5, "button5");
            this.button5.Name = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox11
            // 
            this.textBox11.AcceptsReturn = true;
            resources.ApplyResources(this.textBox11, "textBox11");
            this.textBox11.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.textBox11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            // 
            // Aceleracao_calibracao
            // 
            resources.ApplyResources(this.Aceleracao_calibracao, "Aceleracao_calibracao");
            this.Aceleracao_calibracao.Name = "Aceleracao_calibracao";
            this.Aceleracao_calibracao.UseVisualStyleBackColor = true;
            this.Aceleracao_calibracao.Click += new System.EventHandler(this.Aceleracao_calibracao_Click);
            // 
            // Sem_Aceleracao_calibracao
            // 
            resources.ApplyResources(this.Sem_Aceleracao_calibracao, "Sem_Aceleracao_calibracao");
            this.Sem_Aceleracao_calibracao.Name = "Sem_Aceleracao_calibracao";
            this.Sem_Aceleracao_calibracao.UseVisualStyleBackColor = true;
            this.Sem_Aceleracao_calibracao.Click += new System.EventHandler(this.Sem_Aceleracao_calibracao_Click);
            // 
            // calibrar
            // 
            resources.ApplyResources(this.calibrar, "calibrar");
            this.calibrar.Name = "calibrar";
            this.calibrar.UseVisualStyleBackColor = true;
            this.calibrar.Click += new System.EventHandler(this.calibrar_Click);
            // 
            // textBox7
            // 
            resources.ApplyResources(this.textBox7, "textBox7");
            this.textBox7.Name = "textBox7";
            // 
            // textBox6
            // 
            resources.ApplyResources(this.textBox6, "textBox6");
            this.textBox6.Name = "textBox6";
            // 
            // A_laser
            // 
            resources.ApplyResources(this.A_laser, "A_laser");
            this.A_laser.Name = "A_laser";
            this.A_laser.UseVisualStyleBackColor = true;
            this.A_laser.Click += new System.EventHandler(this.A_laser_Click);
            // 
            // button4
            // 
            resources.ApplyResources(this.button4, "button4");
            this.button4.Name = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // saveFileDialog1
            // 
            resources.ApplyResources(this.saveFileDialog1, "saveFileDialog1");
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            resources.ApplyResources(this.openFileDialog1, "openFileDialog1");
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox4);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Name = "panel2";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox2.Image = global::$safeprojectname$.Properties.Resources.LM2C_Retina__1_downsise;
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Controls.Add(this.groupBox9);
            this.panel3.Controls.Add(this.groupBox5);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Name = "panel3";
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // groupBox9
            // 
            resources.ApplyResources(this.groupBox9, "groupBox9");
            this.groupBox9.Controls.Add(this.portComboBox);
            this.groupBox9.Controls.Add(this.button20);
            this.groupBox9.Controls.Add(this.button11);
            this.groupBox9.Controls.Add(this.button12);
            this.groupBox9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.TabStop = false;
            // 
            // button20
            // 
            resources.ApplyResources(this.button20, "button20");
            this.button20.Name = "button20";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // groupBox5
            // 
            resources.ApplyResources(this.groupBox5, "groupBox5");
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.TabStop = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // groupBox7
            // 
            resources.ApplyResources(this.groupBox7, "groupBox7");
            this.groupBox7.Controls.Add(this.button22);
            this.groupBox7.Controls.Add(this.button21);
            this.groupBox7.Controls.Add(this.button19);
            this.groupBox7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.TabStop = false;
            // 
            // button22
            // 
            resources.ApplyResources(this.button22, "button22");
            this.button22.Name = "button22";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            resources.ApplyResources(this.button21, "button21");
            this.button21.Name = "button21";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button19
            // 
            resources.ApplyResources(this.button19, "button19");
            this.button19.Name = "button19";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // groupBox6
            // 
            resources.ApplyResources(this.groupBox6, "groupBox6");
            this.groupBox6.Controls.Add(this.button16);
            this.groupBox6.Controls.Add(this.button18);
            this.groupBox6.Controls.Add(this.button17);
            this.groupBox6.Controls.Add(this.button15);
            this.groupBox6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.TabStop = false;
            // 
            // button16
            // 
            resources.ApplyResources(this.button16, "button16");
            this.button16.Name = "button16";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button18
            // 
            resources.ApplyResources(this.button18, "button18");
            this.button18.Name = "button18";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            resources.ApplyResources(this.button17, "button17");
            this.button17.Name = "button17";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button15
            // 
            resources.ApplyResources(this.button15, "button15");
            this.button15.Name = "button15";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox3.Image = global::$safeprojectname$.Properties.Resources.LM2C_Retina__1_downsise;
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Controls.Add(this.pictureBox4);
            this.panel4.Controls.Add(this.groupBox10);
            this.panel4.Controls.Add(this.ET12C);
            this.panel4.Controls.Add(this.groupBox8);
            this.panel4.Controls.Add(this.ETExtracao);
            this.panel4.Controls.Add(this.ET12);
            this.panel4.Controls.Add(this.groupBox11);
            this.panel4.Name = "panel4";
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // pictureBox4
            // 
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox4.Image = global::$safeprojectname$.Properties.Resources.LM2C_Retina__1_downsise;
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.TabStop = false;
            // 
            // groupBox10
            // 
            resources.ApplyResources(this.groupBox10, "groupBox10");
            this.groupBox10.Controls.Add(this.button45);
            this.groupBox10.Controls.Add(this.button46);
            this.groupBox10.Controls.Add(this.button47);
            this.groupBox10.Controls.Add(this.textBox19);
            this.groupBox10.Controls.Add(this.button48);
            this.groupBox10.Controls.Add(this.textBox20);
            this.groupBox10.Controls.Add(this.button49);
            this.groupBox10.Controls.Add(this.button50);
            this.groupBox10.Controls.Add(this.label5);
            this.groupBox10.Controls.Add(this.button51);
            this.groupBox10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.TabStop = false;
            // 
            // button45
            // 
            resources.ApplyResources(this.button45, "button45");
            this.button45.Name = "button45";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            resources.ApplyResources(this.button46, "button46");
            this.button46.Name = "button46";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            resources.ApplyResources(this.button47, "button47");
            this.button47.Name = "button47";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // textBox19
            // 
            resources.ApplyResources(this.textBox19, "textBox19");
            this.textBox19.Name = "textBox19";
            // 
            // button48
            // 
            resources.ApplyResources(this.button48, "button48");
            this.button48.Name = "button48";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // textBox20
            // 
            resources.ApplyResources(this.textBox20, "textBox20");
            this.textBox20.Name = "textBox20";
            // 
            // button49
            // 
            resources.ApplyResources(this.button49, "button49");
            this.button49.Name = "button49";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            resources.ApplyResources(this.button50, "button50");
            this.button50.Name = "button50";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // button51
            // 
            resources.ApplyResources(this.button51, "button51");
            this.button51.Name = "button51";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // ET12C
            // 
            resources.ApplyResources(this.ET12C, "ET12C");
            this.ET12C.Controls.Add(this.button52);
            this.ET12C.Controls.Add(this.button54);
            this.ET12C.Controls.Add(this.button55);
            this.ET12C.Controls.Add(this.textBox21);
            this.ET12C.Controls.Add(this.button56);
            this.ET12C.Controls.Add(this.textBox22);
            this.ET12C.Controls.Add(this.button57);
            this.ET12C.Controls.Add(this.button59);
            this.ET12C.Controls.Add(this.label);
            this.ET12C.Controls.Add(this.button60);
            this.ET12C.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ET12C.Name = "ET12C";
            this.ET12C.TabStop = false;
            // 
            // button52
            // 
            resources.ApplyResources(this.button52, "button52");
            this.button52.Name = "button52";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            resources.ApplyResources(this.button54, "button54");
            this.button54.Name = "button54";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            resources.ApplyResources(this.button55, "button55");
            this.button55.Name = "button55";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // textBox21
            // 
            resources.ApplyResources(this.textBox21, "textBox21");
            this.textBox21.Name = "textBox21";
            // 
            // button56
            // 
            resources.ApplyResources(this.button56, "button56");
            this.button56.Name = "button56";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // textBox22
            // 
            resources.ApplyResources(this.textBox22, "textBox22");
            this.textBox22.Name = "textBox22";
            // 
            // button57
            // 
            resources.ApplyResources(this.button57, "button57");
            this.button57.Name = "button57";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button59
            // 
            resources.ApplyResources(this.button59, "button59");
            this.button59.Name = "button59";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // label
            // 
            resources.ApplyResources(this.label, "label");
            this.label.Name = "label";
            this.label.Click += new System.EventHandler(this.ET12C_Click);
            // 
            // button60
            // 
            resources.ApplyResources(this.button60, "button60");
            this.button60.Name = "button60";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // groupBox8
            // 
            resources.ApplyResources(this.groupBox8, "groupBox8");
            this.groupBox8.Controls.Add(this.button38);
            this.groupBox8.Controls.Add(this.button39);
            this.groupBox8.Controls.Add(this.button40);
            this.groupBox8.Controls.Add(this.textBox17);
            this.groupBox8.Controls.Add(this.button41);
            this.groupBox8.Controls.Add(this.textBox18);
            this.groupBox8.Controls.Add(this.button42);
            this.groupBox8.Controls.Add(this.button43);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Controls.Add(this.button44);
            this.groupBox8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.TabStop = false;
            // 
            // button38
            // 
            resources.ApplyResources(this.button38, "button38");
            this.button38.Name = "button38";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            resources.ApplyResources(this.button39, "button39");
            this.button39.Name = "button39";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            resources.ApplyResources(this.button40, "button40");
            this.button40.Name = "button40";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // textBox17
            // 
            resources.ApplyResources(this.textBox17, "textBox17");
            this.textBox17.Name = "textBox17";
            // 
            // button41
            // 
            resources.ApplyResources(this.button41, "button41");
            this.button41.Name = "button41";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // textBox18
            // 
            resources.ApplyResources(this.textBox18, "textBox18");
            this.textBox18.Name = "textBox18";
            // 
            // button42
            // 
            resources.ApplyResources(this.button42, "button42");
            this.button42.Name = "button42";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            resources.ApplyResources(this.button43, "button43");
            this.button43.Name = "button43";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // button44
            // 
            resources.ApplyResources(this.button44, "button44");
            this.button44.Name = "button44";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // ETExtracao
            // 
            resources.ApplyResources(this.ETExtracao, "ETExtracao");
            this.ETExtracao.Controls.Add(this.button25);
            this.ETExtracao.Controls.Add(this.button32);
            this.ETExtracao.Controls.Add(this.button33);
            this.ETExtracao.Controls.Add(this.textBox13);
            this.ETExtracao.Controls.Add(this.button34);
            this.ETExtracao.Controls.Add(this.textBox14);
            this.ETExtracao.Controls.Add(this.button35);
            this.ETExtracao.Controls.Add(this.button36);
            this.ETExtracao.Controls.Add(this.label3);
            this.ETExtracao.Controls.Add(this.button37);
            this.ETExtracao.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ETExtracao.Name = "ETExtracao";
            this.ETExtracao.TabStop = false;
            // 
            // button25
            // 
            resources.ApplyResources(this.button25, "button25");
            this.button25.Name = "button25";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button32
            // 
            resources.ApplyResources(this.button32, "button32");
            this.button32.Name = "button32";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            resources.ApplyResources(this.button33, "button33");
            this.button33.Name = "button33";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // textBox13
            // 
            resources.ApplyResources(this.textBox13, "textBox13");
            this.textBox13.Name = "textBox13";
            // 
            // button34
            // 
            resources.ApplyResources(this.button34, "button34");
            this.button34.Name = "button34";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // textBox14
            // 
            resources.ApplyResources(this.textBox14, "textBox14");
            this.textBox14.Name = "textBox14";
            // 
            // button35
            // 
            resources.ApplyResources(this.button35, "button35");
            this.button35.Name = "button35";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            resources.ApplyResources(this.button36, "button36");
            this.button36.Name = "button36";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // button37
            // 
            resources.ApplyResources(this.button37, "button37");
            this.button37.Name = "button37";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // ET12
            // 
            resources.ApplyResources(this.ET12, "ET12");
            this.ET12.Controls.Add(this.button31);
            this.ET12.Controls.Add(this.button30);
            this.ET12.Controls.Add(this.button29);
            this.ET12.Controls.Add(this.textBox5);
            this.ET12.Controls.Add(this.button28);
            this.ET12.Controls.Add(this.textBox3);
            this.ET12.Controls.Add(this.button27);
            this.ET12.Controls.Add(this.button26);
            this.ET12.Controls.Add(this.label2);
            this.ET12.Controls.Add(this.button24);
            this.ET12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ET12.Name = "ET12";
            this.ET12.TabStop = false;
            // 
            // button31
            // 
            resources.ApplyResources(this.button31, "button31");
            this.button31.Name = "button31";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            resources.ApplyResources(this.button30, "button30");
            this.button30.Name = "button30";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            resources.ApplyResources(this.button29, "button29");
            this.button29.Name = "button29";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // textBox5
            // 
            resources.ApplyResources(this.textBox5, "textBox5");
            this.textBox5.Name = "textBox5";
            // 
            // button28
            // 
            resources.ApplyResources(this.button28, "button28");
            this.button28.Name = "button28";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // textBox3
            // 
            resources.ApplyResources(this.textBox3, "textBox3");
            this.textBox3.Name = "textBox3";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // button27
            // 
            resources.ApplyResources(this.button27, "button27");
            this.button27.Name = "button27";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            resources.ApplyResources(this.button26, "button26");
            this.button26.Name = "button26";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // button24
            // 
            resources.ApplyResources(this.button24, "button24");
            this.button24.Name = "button24";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // groupBox11
            // 
            resources.ApplyResources(this.groupBox11, "groupBox11");
            this.groupBox11.Controls.Add(this.button53);
            this.groupBox11.Controls.Add(this.label6);
            this.groupBox11.Controls.Add(this.button58);
            this.groupBox11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.TabStop = false;
            // 
            // button53
            // 
            resources.ApplyResources(this.button53, "button53");
            this.button53.Name = "button53";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // button58
            // 
            resources.ApplyResources(this.button58, "button58");
            this.button58.Name = "button58";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.button10;
            resources.ApplyResources(this, "$this");
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Parâmetros_Motor.ResumeLayout(false);
            this.Parâmetros_Motor.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel3.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ET12C.ResumeLayout(false);
            this.ET12C.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ETExtracao.ResumeLayout(false);
            this.ETExtracao.PerformLayout();
            this.ET12.ResumeLayout(false);
            this.ET12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox Parâmetros_Motor;
        private System.Windows.Forms.Button Enviar;
        private System.Windows.Forms.Button Velocity;
        private System.Windows.Forms.Button Direction2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button PulseQntd;
        private System.Windows.Forms.Button Direction;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SemAcelerar;
        private System.Windows.Forms.Button En_Button;
        private System.Windows.Forms.Button onButton;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button StopButton;
        private System.IO.Ports.SerialPort serialPort2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button ModoCalibracao;
        private System.Windows.Forms.Button ModoMovimentacao;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button A_laser;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button calibrar;
        private System.Windows.Forms.Button Sem_Aceleracao_calibracao;
        private System.Windows.Forms.Button Aceleracao_calibracao;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.ComboBox portComboBox;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.GroupBox ET12;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.GroupBox ETExtracao;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.GroupBox ET12C;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Button button60;
    }
}

